# Discover Mushrooms in Finland - WordPress Theme

## Description

This is a custom WordPress theme designed for a website about mushrooms in Finland. The site explores mushroom species, health benefits, guided tours, and safe mushroom picking. The theme is responsive, user-friendly, and includes custom styles and templates for a unique look and feel.

## Features

- **Custom Design**: Aesthetic and functional design with a focus on nature and mushrooms.
- **Responsive Layout**: Fully responsive for mobile, tablet, and desktop devices.
- **Custom Templates**: Includes templates for the homepage, single posts, and pages.
- **Hero Section**: A visually appealing hero section with a call-to-action button.
- **Sidebar Widgets**: Support for widgets in the sidebar.
- **Custom Navigation**: A burger menu for mobile devices.
- **Post Thumbnails**: Support for featured images in posts.
- **Custom Excerpts**: "Read More" links for post excerpts.

## Installation

1. Clone or download this repository into your WordPress `themes` directory:
   ```bash
   git clone <repository-url> /path/to/wordpress/wp-content/themes/nature
   ```
2. Activate the theme in the WordPress admin panel:
   - Go to **Appearance > Themes**.
   - Find "Discover Mushrooms in Finland" and click **Activate**.

## Setup

1. **Menus**:

   - Go to **Appearance > Menus**.
   - Create a menu and assign it to the "Primary Menu" location.

2. **Widgets**:

   - Go to **Appearance > Widgets**.
   - Add widgets to the "Sidebar" area.

3. **Permalinks**:

   - Go to **Settings > Permalinks**.
   - Set the permalink structure to "Post name" for better SEO.

4. **Hero Section Background**:

   - Replace the `forest-hero.jpg` file in the theme directory with your desired hero image.

5. **Custom Logo**:
   - Add a custom logo or update the site title in **Settings > General**.

## File Structure

- `style.css`: Contains all the styles for the theme.
- `functions.php`: Registers theme features, scripts, and widgets.
- `header.php`: Contains the header section, including the navigation menu.
- `footer.php`: Contains the footer section with social links.
- `front-page.php`: Template for the homepage.
- `page.php`: Template for static pages.
- `single.php`: Template for single blog posts.
- `index.php`: Fallback template for blog posts.
- `home.php`: Template for the blog page.

## Development

### Prerequisites

- WordPress installed locally or on a server.
- Basic knowledge of PHP, HTML, CSS, and WordPress theme development.

### Customization

Feel free to modify the theme files to suit your needs. Key areas to customize:

- **Colors and Fonts**: Update in `style.css`.
- **Hero Section**: Modify in `front-page.php`.
- **Footer Links**: Update in `footer.php`.

## Credits

- **Author**: Anna Shi
- **Portfolio**: [https://portfolio-a8654.web.app/index.html](https://portfolio-a8654.web.app/index.html)

## License

This theme is licensed under the [MIT License](https://opensource.org/licenses/MIT).

## Support

For issues or feature requests, please contact the author via the portfolio link above.
