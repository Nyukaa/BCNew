<div id='sidebar'>
<?php
dynamic_sidebar ('sidebar');?>
</div>